../../../bin/pfaces -CG -k pirk.cpu@../../kernel-pack -cfg ./ex_quad_apf.cfg -d 1 -p -co "save_result=true,mem_efficient=true,method_choice=1,states.dim=24,inputs.dim=24"
